# 舒适阅读 v2 · 历史专题

本目录保留当时的字幕设计，视觉内容不作本轮更新，不再作为当前完整设计入口。请使用[首版整稿](../first-product-v1/index.html)、[当前模型配置](../first-product-v1/index.html?scenario=settings)及[完整使用旅程](../first-product-v1/entry-flow.html)。[材质案例](../macos-material-case-v1/index.html)的风格已确认；该确认不覆盖本历史专题或整稿布局，整稿仍待评审，产品回归保持 `NOT_RUN`。

[打开历史专题](index.html)。单文件包含样式、交互、自造日语样句与原创 SVG 图书馆场景，可直接离线查看。原 v1 和原 22 屏稿保持原样；本历史稿保留 `not_reviewed` 状态。

[模型配置 v1](../model-configuration-v1/index.html)同样保留为历史专题；本v2中的服务片段是当时示意。当前配置与阅读往返以整稿的设置窗口和使用旅程为准。

## 历史版本的设计调整

- 首屏只突出一个推荐字幕面板，普通阅读对照折叠，完整 v1 另有链接。
- 阅读正文使用更稳定的标准磨砂材质示意，轻层次留给底部控制区域。20 px 圆角、细内边与双层软阴影帮助识别窗口轮廓；没有把正文做成高透明透镜。
- 新增**舒适预设**：560 pt 宽、日文 18 pt / 中文 24 pt。**紧凑预设**保留原 500 pt、16 / 22；这些是当时的提案，不宣称与原确认稿指标完全相同。
- 原文主要保持中性文字，注音独立占行。假名最小 10 px，HUD 200% 缩放时相应放大至至少 20 px。词性从逐词底框、重下划线改为低饱和小色点；选词后才显示柔和高亮。词卡保留文字词性，颜色不是唯一信息。
- 点击词语后，短释义卡锚定词语就近浮出，不推高字幕面板。完整查词打开独立学习面板，按需文法仍在独立视图中展示。
- 长文正文有独立滚动区域、可见滚动条与“可滚动”提示，32 pt 控制条始终留在正文滚动区外，仅暂停与更多两个常驻按钮。正常阅读不常驻状态文案，暂停时显示“已暂停”。
- 场景背景与 HUD 明暗外观独立设置；默认明亮场景，深色 HUD 也可以在相同明亮背景上检查可读性。
- 减少透明度切换为不透明表面，提高对比度增强文字和轮廓。CSS 同时提供减少动态效果与系统高对比度的响应。

## 可以操作的设计状态

| 内容 | 控件 / selector |
| --- | --- |
| 推荐 HUD / 场景 | `#hud-after` / `.stage` / `.library-scene` |
| 分词、假名、词性、分隔 | `#segmentation` / `#furigana` / `#pos-colors` / `#boundaries` |
| 背景明亮、夜间 | `#scene`，值 `day` / `night`；与 HUD 主题完全独立 |
| 浅色、深色 | `#theme`，值 `light` / `dark` |
| 减少透明度 | `#appearance`，值 `standard` / `reduced` |
| 提高对比度 | `#high-contrast` |
| 舒适、紧凑 | `#preset`，值 `comfortable` / `compact` |
| 普通句、长句、200% | `#sentence`，值 `short` / `long`；`#scale`，值 `1` / `2` |
| 开启短词卡 | 点击 `#source-after [data-token="2"]`（普通句的“図書館”）；弹层 `#word-popover` |
| 关闭短词卡 | `#close-word`、Escape 或弹层外点击；焦点返回原词 |
| 完整学习面板 | `#full-dictionary` → `#learning-panel`；`#close-learning` 或 Escape 关闭 |
| 进入文法分析 | 词卡 `#word-grammar` 或更多菜单 `#grammar-shortcut` |
| 句子结构引用 | `#structure .clause`；`data-token-refs` 为自造 fixture 的显式引用集 |
| 文法状态 | `[data-analysis-state]` 的 `ready` / `loading` / `failure` / `stale` |
| 长文滚动线索 | `#hud-reading-area` / `#scroll-indicator` |
| 普通阅读对照 | `#baseline-comparison`，默认折叠 |

设计视图 tabs 支持左右键、Home / End；原文词语为可键盘操作按钮，词卡与学习面板可用 Escape 关闭。系统焦点和游戏前台行为尚未由这个 HTML 证明。

## 快捷评审链接参数

- `?view=reading&theme=light&sentence=short&scale=1&appearance=standard&scene=day&preset=comfortable`
- `?view=reading&theme=dark&sentence=short&scale=1&appearance=standard&scene=day&preset=comfortable`
- `?view=reading&theme=light&sentence=long&scale=2&appearance=reduced&scene=day&preset=compact`
- `?view=analysis&theme=light&sentence=short`
- `?view=settings&settings=learning&theme=light`
- `?view=settings&settings=services&theme=light`

同为 `scene=day` 时，浅/深 HUD 使用完全相同的场景亮度与场景遮罩；背景不会因 HUD 切深色而自动变暗。可另加 `scene=night` 检查夜间场景。

未列出的开关保存在当前网页内存，不写入应用配置。

## 沿用的产品约束

分词引擎与基础 UniDic 辞书随客户端内置，首次打开无需安装词典；内置版本只读查看。MeCab / UniDic 不提供中文释义，基础释义资源需独立选择并核实分发授权。`kana` 假名形与 `pron` 发音形不混用，未知读音不猜测。混合汉字假名词保留送假名。

设置沿用原十类信息架构；日语学习属于通用下的阅读详情，不增加新常驻类别。翻译与文法用途可以复用连接、选择不同模型；文法按需请求。旧句解释不会覆盖 HUD 最新原文和译文。文法结构点击完整高亮引用词组，不修改本地词性。

## 设计与验证边界

本页是 HTML 材质示意，**并非原生 Liquid Glass 实现**。遵循正文标准材质、阅读层级与可访问性方向；不会据此宣称原生窗口材质、辅助技术或对比度已通过全部系统场景。

所有分词、读音、词义、译文与文法解释均为人工编写的自造 fixture；原始句子可以完整拼回，文法引用显式对应全部词组 token。这不代表真实分词器输出或模型能力。页面不会发送服务请求、安装资源、保存凭据，也不会操作真实游戏。

本次仅检查了 JavaScript 可解析、自造样句/ruby/完整文法引用一致性。截图、视觉复查和浏览器交互由本轮统一 QA 另记；置顶、点击穿透、游戏前台不夺焦点、多屏与正式客户端回归仍待实施。

## 本轮截图与检查

[新旧对照画廊](gallery.html)包含16张预览（含细节和滚动位置）。[Playwright记录](previews/verification.json)验证了同一明亮背景下的浅深色、完整词组高亮、词卡Esc/外部关闭与焦点恢复、舒适/紧凑、减少透明度、提高对比度、长文200%滚动及390px各视图。0网络请求、0控制台错误；此结果不属于产品、真实分词/模型或原生窗口回归。

## 从哪里进入文法分析

[查看入口流程图](entry-flow.html)。字幕右下“…”→“分析本句文法…”；也可点击原文词语→词卡→“分析本句文法”。前者分析点击时的字幕当前句，后者分析词卡所属句。顶部“文法与学习”仅为设计稿切换。正式产品打开独立学习窗并固定原句；未配置文法用途时保留原句并引导配置，用户再开始分析。当前HTML为视图演示与自造结果，未调用模型。
