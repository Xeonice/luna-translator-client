# 模型配置 v1 · 历史专题

日期：2026-10-18 · 状态：历史提案，保留 `not_reviewed`。

当前完整入口为[首版整稿](../first-product-v1/index.html)，模型配置使用其[设置窗口](../first-product-v1/index.html?scenario=settings)及[完整使用旅程](../first-product-v1/entry-flow.html)。[材质案例](../macos-material-case-v1/index.html)的风格已确认；该确认不覆盖本历史专题或整稿布局，整稿仍待评审，产品回归保持 `NOT_RUN`。

[打开历史专题](index.html) · [历史截图画廊](gallery.html) · [当时的阅读配置流程](entry-flow.html) · [模型配置 PRD](../../product/model-configuration-prd.md)

本历史稿承接模型配置PRD的16条AI-CFG，记录当时的配置、测试、应用与阅读返回状态。其视觉沿用[字幕 v2 历史专题](../japanese-study-v2/index.html)，本轮不改动HTML、样式、脚本和截图。原22屏、100文件产品快照和v1/v2字幕稿保留。它是独立的SCR-15细化，不新增常驻设置类别。

## 页面与状态

| 内容页 | 可以评审什么 |
|---|---|
| 用途绑定 | 翻译、句子精读、语境查词分别绑定与启用；多翻译器；全局与游戏覆盖；未配置与被连接阻断 |
| 服务连接 | 协议、地址、部署位置、认证引用；共享连接停用、恢复与删除影响；凭据池状态 |
| 模型 | 所属连接、显示名和实际ID；发现失败后的手填；能力来源与输出模式 |
| 参数与模板 | 用途模板、上下文、术语、参数继承/显式/省略、有效请求预览 |
| 运行与数据 | 草稿/已应用版本、并发超时重试、显式回退、缓存与人工来源、配置档及导入导出 |

测试、应用、共享停用/恢复、删除和导入预检以弹窗表达影响，不让“保存”承担执行服务请求或切换在用配置的语义。测试状态按连接、模型和具体用途分开；演示成功也不表示模型真实可用。

## 推荐评审路径

1. 打开“用途绑定”，查看翻译/精读/查词及其生效来源。
2. 到“服务连接”修改一个字段，保存草稿，再查看已应用版本是否保持；点击应用查看影响确认。
3. 打开测试，检查样例、发送范围和分层结果，再切失败/需重新测试/停用状态。
4. 到“模型”查看列表失败与手填，到“参数与模板”切换参数三态及有效请求预览。
5. 切到阅读预览，从字幕“…”或词卡进入未配置的文法用途；保留原句去配置、应用并启用后返回，再主动开始。模拟新台词时，待分析对象保持原句。

## 直接打开状态

本地打开 `index.html` 后可通过预览栏切换；也可以使用以下查询参数：

- `?view=settings&tab=purposes&theme=light`
- `?view=settings&tab=connections&state=dirty`
- `?view=settings&tab=models&state=failure`
- `?view=settings&tab=parameters&scope=game`
- `?view=settings&tab=advanced&theme=dark`
- `?view=settings&tab=purposes&state=disabled`
- `?view=reading&state=unconfigured`

预览工具在应用窗口外；正式产品不包含设计状态切换器。设置保留10类单层导航，服务/模型选择在同一内容表单中，详细项通过页签与展开区呈现。桌面采用约1000×720的窗口比例，窄视口重排以便评审，不据此扩张正式产品支持平台。

## 证据与边界

需求对应见[覆盖清单](coverage.csv)，浏览器交互/截图检查见[verification.json](previews/verification.json)。16条需求的界面归属齐全不等于全部产品行为已实现；仍以PRD的22条MC及正式产品回归为执行标准。未在原型运行的凭据存储、跨实例隔离、网络请求、迁移和供应商错误仅表达设计意图。

本轮Playwright保存28张截图，检查五页签、浅深色、草稿/已应用版本、分层测试、参数三态、启用校验、共享停用/恢复、凭据版本、导入预检、显式回退、键盘与390px布局。字幕更多和词卡两条入口均实点；词卡打开后推进字幕再分析，仍使用词卡原句。配置返回保留原对象且由用户主动开始。0 HTTP请求、0控制台错误。

重新生成证据与画廊：

```sh
node scripts/report/verify_model_configuration_design.cjs
python3 scripts/report/build_model_configuration_gallery.py
```

以上命令从项目根目录执行，使用既有的Playwright/Chrome检查环境。打包前校验HTML/CSS/JS与浏览器证据的哈希一致。

所有连接、模型、日语样句、译文和测试结果均为设计数据。页面不调用真实API，不安装模型，不保存真实密钥；页面内状态不代表客户端持久化。HTML表面是视觉近似，原生窗口材质、焦点、游戏输入和辅助技术须在最终客户端另行验证。产品回归保持`NOT_RUN`，用户视觉评审保持`not_reviewed`。

本目录含HTML、CSS、JavaScript及截图，均可离线阅读；[ZIP](../../../reports/model-configuration-design-20261018.zip)另附PRD与验收清单快照。
