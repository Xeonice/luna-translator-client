# 日语阅读与模型辅助 v1 · 历史专题

本目录保留当时的分词与精读设计，视觉内容不作本轮更新，不再作为当前完整设计入口。请使用[首版整稿](../first-product-v1/index.html)、[当前模型配置](../first-product-v1/index.html?scenario=settings)及[完整使用旅程](../first-product-v1/entry-flow.html)。[材质案例](../macos-material-case-v1/index.html)的风格已确认；该确认不覆盖本历史专题或整稿布局，整稿仍待评审，产品回归保持 `NOT_RUN`。

[打开历史专题](index.html)。单文件包含全部样式、脚本和自造样句，可离线打开，无需构建或网络请求。本历史稿保留 `not_reviewed` 状态；原 22 屏的确认不扩张到本稿。

## 可评审内容

1. **开启后的阅读**：关闭与开启的 500 pt HUD 对照；默认显示注音与词性轻底色，分词、假名、词性、分隔独立切换。点击词语更新短释义卡。浅深色、长句、200% 可切换。
2. **按需文法分析**：固定原文，展示结构、助词与活用；点击结构块定位原文词组。支持切换完成、分析中、失败、新句到达。新句状态下，HUD 当前句与正在分析的旧句分别显示。
3. **设置与模型**：沿用十类设置导航。通用下的日语学习详情提供本地分词资源与呈现设置；翻译服务区分实时翻译和按需文法分析的模型用途。分词引擎与基础 UniDic 辞书随客户端内置，无需首次安装；内置版本只读查看。

快捷评审地址参数：

- `?view=reading&theme=light&sentence=short&scale=1`
- `?view=reading&theme=dark&sentence=long&scale=2`
- `?view=analysis&theme=light&sentence=short&scale=1`
- `?view=settings&settings=learning&theme=light`
- `?view=settings&settings=services&theme=light`

参数未列出的开关只保存在本页内存，不持久化到产品配置。

## 与原设计的关系

- SCR-01：分词、ruby 注音与词性可选样式，原文 16 pt、译文 22 pt、32 pt 固定操作行。注音使高度自然增长，不承诺继续固定 132 pt。
- SCR-09：短词卡、完整查词入口与按需文法辅助窗。
- SCR-12：通用 → 阅读 → 日语学习，不增加新的常驻侧栏类别。
- SCR-15：服务连接及不同用途的模型配置。
- SCR-18：呈现样式，假名与阅读字号。
- SCR-17 仍是语音设置；不将其重命名为语言学习。

参考原稿 tokens 与布局：`docs/product/original/docs/02-design-spec.md`；行为参考 [LunaTranslator 注音与分词说明](https://docs.lunatranslator.org/zh/qa1.html)。

## 数据与验证边界

- 所有台词、分组、读音、中文词义和文法解释均为人工编写的自造设计数据。展示分组不代表 MeCab / UniDic 的实际输出。
- 混合词如“待ち合わせ”保留送假名；不把每个假名再标注读音。拟议运行行为为可靠对齐优先，不能可靠对齐时整词注音；未知读音不猜。
- UniDic 假名形 `kana` 与发音形 `pron` 不混用。分词引擎与基础辞书计划随正式应用内置并随客户端更新，首次启动开箱即用；本稿尚未实装或打包引擎与辞书。分词器并不提供中文释义，词义来自独立的基础释义资源，其具体来源与分发授权在开发前核实。
- 网页不会请求真实模型、下载词典或写入密钥。模型名称、内置资源说明和连接状态仅为设计样本。
- HTML 中的暂停、菜单及置顶入口不证明原生窗口焦点、穿透、多屏、辅助技术及游戏行为；仍需正式客户端产品回归。
- 已完成静态检查：JavaScript 可解析，两个样句均满足 token 拼回原文，ruby 表面和读音与词条一致，文法词组的显式 token 引用集可完整拼回所引用原文。浏览器截图与视觉状态由本轮统一 QA 记录，不在这里冒称通过。

## 本轮设计 QA

[截图画廊](gallery.html)包含9个状态，见[验证记录](previews/verification.json)和[设计清单](manifest.json)。Playwright离线检查通过，0 HTTP请求/0控制台错误，覆盖开关、完整词组高亮、内置词典设计、分析状态、长文200%与窄窗。用户状态仍为not_reviewed；这不是生产客户端、真实分词或模型回归通过。
