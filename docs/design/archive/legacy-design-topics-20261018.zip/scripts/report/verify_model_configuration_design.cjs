/* Offline artifact QA. These checks do not execute the product's MC cases. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const { chromium } = require(path.resolve(__dirname, '../../.build/report-browser/node_modules/playwright-core'));

async function main() {
  const input = path.resolve(process.argv[2] || 'docs/design/model-configuration-v1/index.html');
  const output = path.resolve(process.argv[3] || 'docs/design/model-configuration-v1/previews');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.REPORT_BROWSER_EXECUTABLE || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true, args: ['--disable-background-networking'] });
  const errors = [], requests = [], checks = [], captures = [];
  try {
    const context = await browser.newContext({ offline: true, viewport: { width: 1440, height: 1080 }, reducedMotion: 'reduce' });
    const page = await context.newPage();
    page.setDefaultTimeout(8000);
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
    page.on('request', request => { if (/^https?:/.test(request.url())) requests.push(request.url()); });
    const open = async query => {
      await page.goto(pathToFileURL(input).href + '?' + query);
      await page.evaluate(() => document.fonts.ready);
      await page.waitForFunction(() => !!window.modelConfigDesign);
    };
    const shot = async (file, title, selector = '#settings-window', group = 'settings', description = '') => {
      await page.locator(selector).screenshot({ path: path.join(output, file), animations: 'disabled' });
      captures.push({ file, title, group, description });
    };
    const noOverflow = async () => {
      const widths = await page.evaluate(() => ({ page: document.documentElement.scrollWidth, viewport: document.documentElement.clientWidth, content: document.querySelector('#settings-content')?.scrollWidth, visibleContent: document.querySelector('#settings-content')?.clientWidth }));
      assert.ok(widths.page <= widths.viewport + 1, `Document overflow: ${JSON.stringify(widths)}`);
      if (await page.locator('#settings-window').isVisible()) assert.ok(widths.content <= widths.visibleContent + 1, `Form overflow: ${JSON.stringify(widths)}`);
    };

    const tabs = [
      ['purposes', '01-purpose-bindings.png', '用途绑定 · 翻译、精读和语境查词'],
      ['connections', '02-service-connection.png', '服务连接 · 协议、地址和认证'],
      ['models', '03-model-profiles.png', '模型 · 显示名与实际ID'],
      ['parameters', '04-parameters-template.png', '参数与模板 · 有效值及输入范围'],
      ['advanced', '05-runtime-data.png', '运行与数据 · 版本和请求策略'],
    ];
    for (const [tab, file, title] of tabs) {
      await open(`view=settings&tab=${tab}&theme=light`);
      assert.equal(await page.locator('[role=tab][aria-selected=true]').getAttribute('data-tab'), tab);
      assert.equal(await page.locator('#settings-nav .nav-item').count(), 10);
      assert.deepEqual(await page.locator('#settings-nav .nav-item').evaluateAll(items => items.map(item => item.lastChild.textContent.trim())), ['通用','输入与 HOOK','OCR 引擎','翻译服务','文本处理','语音','显示与快捷键','网络服务','配置与数据','更新与诊断']);
      await noOverflow();
      await shot(file, title);
    }
    checks.push('five_content_tabs_ten_single_level_settings_categories_and_desktop_form_layout');
    await open('view=settings&tab=connections&state=dirty');
    await shot('06-unapplied-draft.png', '未应用修改 · 草稿与运行版本分开');
    await open('view=settings&tab=connections&state=stale');
    await shot('07-stale-test.png', '配置修改后，原测试结果需重新验证');
    await open('view=settings&tab=purposes&state=disabled');
    await shot('08-shared-connection-disabled.png', '共享连接停用 · 保留用途绑定并说明阻断');
    await open('view=settings&tab=parameters&scope=game');
    await shot('09-game-scope.png', '当前游戏覆盖 · 继承、显式设置与省略');
    await open('view=settings&tab=purposes&theme=dark');
    assert.equal(await page.locator('html').getAttribute('data-theme'), 'dark');
    await shot('10-dark-appearance.png', '深色设置 · 独立表面和文字层级');
    checks.push('draft_stale_disabled_game_scope_and_dark_appearance_design_states');

    await open('view=settings&tab=connections');
    const applied = await page.evaluate(() => window.modelConfigDesign.state.appliedVersion);
    await page.locator('#endpoint').fill('https://new-service.example/v1');
    await page.locator('#save-draft').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.appliedVersion), applied);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.pending), true);
    assert.match(await page.locator('#version-info').textContent(), /已保存，尚未应用/);
    await shot('11-saved-draft.png', '保存草稿 · 已应用配置保持原版本');
    await page.locator('#apply-config').click();
    assert.equal(await page.locator('#design-dialog').isVisible(), true);
    assert.match(await page.locator('#design-dialog').textContent(), /在途请求取消/);
    await shot('12-apply-impact.png', '应用确认 · 版本、用途与在途影响', '#design-dialog');
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#design-dialog').isVisible(), false);
    assert.equal(await page.locator('#apply-config').evaluate(el => document.activeElement === el), true);
    await page.locator('#apply-config').click();
    await page.locator('[data-action="confirm-apply"]').click();
    assert.ok(await page.evaluate(() => window.modelConfigDesign.state.appliedVersion > 3));
    checks.push('save_draft_keeps_applied_version_apply_discloses_impact_escape_returns_focus');

    await page.locator('[data-action="test"]').first().click();
    await page.locator('#test-outcome').selectOption('failure');
    await page.locator('[data-action="run-test"]').click();
    assert.match(await page.locator('#test-results').textContent(), /连接与认证/);
    assert.match(await page.locator('#test-results').textContent(), /句子精读/);
    assert.match(await page.locator('#test-results').textContent(), /未通过/);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.test), 'failure');
    await shot('13-layered-test-failure.png', '测试分层 · 连通和翻译通过，文法仍失败', '#design-dialog');
    await page.keyboard.press('Escape');
    await page.locator('#save-draft').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.test), 'failure');
    checks.push('layered_test_failure_does_not_promote_grammar_and_can_still_save');

    await open('view=settings&tab=models');
    const model = await page.locator('#model-id').inputValue();
    await page.locator('[data-action="refresh-models"]').click();
    assert.equal(await page.locator('#model-id').inputValue(), model);
    assert.match(await page.locator('#model-list-note').textContent(), /失败/);
    await page.locator('#model-id').fill('manual-model-id');
    await page.locator('#save-draft').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.modelId), 'manual-model-id');
    await shot('14-manual-model.png', '模型列表失败 · 保留选择并允许手填');
    checks.push('model_listing_failure_preserves_selection_and_manual_id_edit');

    await open('view=settings&tab=connections&state=unconfigured');
    await page.locator('#endpoint').fill('');
    await page.locator('#tab-purposes').click();
    await page.locator('#grammar-model').selectOption('study');
    await page.locator('#grammar-enabled').check();
    await page.locator('[data-action="confirm-enable"]').click();
    assert.match(await page.locator('#design-dialog').textContent(), /服务地址/);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.grammarEnabled), false);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.appliedVersion), 3);
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#grammar-enabled').isChecked(), false);
    checks.push('first_enable_uses_same_local_validation_as_apply_and_invalid_toggle_is_restored');

    await open('view=settings&tab=parameters&scope=game');
    await page.locator('#temperature-mode').selectOption('omit');
    assert.equal(await page.locator('#temperature').isDisabled(), true);
    await page.locator('[data-action="request-preview"]').click();
    assert.match(await page.locator('#design-dialog').textContent(), /温度：省略/);
    await shot('15-effective-request.png', '有效请求预览 · 参数省略、输入范围与来源', '#design-dialog');
    await page.keyboard.press('Escape');
    await page.locator('#temperature-mode').selectOption('explicit');
    await page.locator('#temperature').fill('0');
    await page.locator('[data-action="request-preview"]').click();
    assert.match(await page.locator('#design-dialog').textContent(), /温度：0（显式设置）/);
    await page.keyboard.press('Escape');
    await page.locator('#prompt-template').fill('原句：{{sentence}} 未知：{{secret}}');
    await page.locator('#apply-config').click();
    assert.match(await page.locator('#design-dialog').textContent(), /未知模板变量/);
    await page.keyboard.press('Escape');
    checks.push('parameter_omit_and_zero_are_distinct_effective_preview_and_invalid_template_blocks_apply');

    await open('view=settings&tab=connections');
    await page.locator('#connection-enabled').uncheck();
    await shot('16-disable-impact.png', '停用共享连接 · 列出受影响用途', '#design-dialog');
    await page.locator('[data-action="confirm-disable"]').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.connectionEnabled), false);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.grammarEnabled), true);
    await page.locator('#settings-window [data-action="restore"]').click();
    await page.locator('[data-action="confirm-restore"]').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.connectionEnabled), true);
    await page.locator('[data-action="keys"]').click();
    await page.locator('[data-action="replace-key"]').click();
    assert.deepEqual(await page.evaluate(() => [window.modelConfigDesign.state.appliedKeyVersion, window.modelConfigDesign.state.keyVersion]), [2, 3]);
    await shot('17-key-versions.png', '凭据与密钥池 · 新旧版本和测试范围', '#design-dialog');
    await page.keyboard.press('Escape');
    checks.push('shared_connection_stop_restore_and_credential_versions_require_explicit_apply');

    await open('view=settings&tab=advanced');
    await page.locator('[data-action="import"]').click();
    assert.equal(await page.locator('#import-confirm').isDisabled(), true);
    await page.locator('[data-action="preflight-import"]').click();
    assert.equal(await page.locator('#import-confirm').isEnabled(), true);
    assert.match(await page.locator('#import-results').textContent(), /凭据引用需在本机重新关联/);
    await shot('18-import-preflight.png', '导入预检 · 冲突、凭据与回退', '#design-dialog');
    await page.keyboard.press('Escape');
    await page.locator('[data-action="fallback"]').click();
    await page.locator('[data-action="confirm-fallback"]').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.fallback), false);
    await page.locator('#fallback-consent').check();
    await shot('19-explicit-fallback.png', '回退规则 · 明确服务、范围和用量', '#design-dialog');
    await page.locator('[data-action="confirm-fallback"]').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.fallback), true);
    checks.push('import_preflight_before_confirmation_and_fallback_requires_explicit_consent');

    await open('view=reading&state=unconfigured');
    assert.equal(await page.locator('.hud-footer').evaluate(el => Math.round(el.getBoundingClientRect().height)), 32);
    assert.equal(await page.locator('#live-translation').evaluate(el => parseFloat(getComputedStyle(el).fontSize)), 22);
    await page.locator('#hud-pause').click();
    assert.equal(await page.locator('#hud-status').textContent(), '已暂停');
    await page.locator('#hud-pause').click();
    await page.locator('#hud-more').click();
    await shot('22-reading-entry.png', '① 字幕更多 · 分析本句文法', '#reading-window', 'entry', '日常入口在字幕右下“…”；可从词卡进入同一句。');
    await page.locator('#analyze-menu').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.retainedIndex), 0);
    await shot('23-unconfigured-sentence.png', '② 文法尚未配置 · 原句已保留', '#reading-window', 'entry', '翻译与基础词典继续；配置不会偷偷借用翻译用途。');
    await page.locator('#advance-sentence').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.liveIndex), 1);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.retainedIndex), 0);
    await page.locator('#configure-reading').click();
    await page.locator('#grammar-model').selectOption('study');
    assert.equal(await page.locator('#grammar-enabled').isChecked(), false);
    assert.match(await page.locator('#apply-config').textContent(), /应用并启用精读/);
    await shot('24-configure-retained-sentence.png', '③ 配置句子精读 · 保留返回路径', '#settings-window', 'entry', '选择所需模型和发送范围，明确应用并启用。');
    await page.locator('#apply-config').click();
    assert.match(await page.locator('#design-dialog').textContent(), /应用并启用/);
    await page.locator('[data-action="confirm-apply"]').click();
    assert.equal(await page.locator('#reading-window').isVisible(), true);
    assert.equal(await page.locator('#start-analysis').isVisible(), true);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.retainedIndex), 0);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.readingStep), 'ready');
    await shot('25-return-before-analysis.png', '④ 返回原句 · 由用户开始分析', '#reading-window', 'entry', '左侧字幕已推进，右侧仍保留最初那句；返回不自动分析。');
    await page.locator('#start-analysis').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.readingStep), 'complete');
    await shot('26-analysis-result.png', '⑤ 查看原句解释 · 字幕继续', '#reading-window', 'entry', '人工编写的解释示例；配置与浏览器检查不代表真实模型输出。');
    await open('view=reading&state=unconfigured');
    await page.locator('#source-word').click();
    await shot('27-word-card-entry.png', '词卡入口 · 从内置释义进入句子精读', '#reading-window', 'entry', '基础词典与模型解释分别呈现；首启不要求先配置模型才能查词。');
    await page.locator('#advance-sentence').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.liveIndex), 1);
    await page.locator('#wordcard-analyze').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.retainedIndex), 0, 'Word-card analysis must use its original sentence after live text advances');
    assert.equal(await page.locator('#configure-reading').isVisible(), true);
    await page.locator('#configure-reading').click();
    await page.locator('#return-reading').click();
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.retainedIndex), 0);
    assert.equal(await page.locator('#configure-reading').isVisible(), true);
    checks.push('hud_fixed_controls_pause_more_wordcard_entry_retained_sentence_roundtrip_and_user_started_analysis');

    await open('view=reading&state=disabled');
    assert.equal(await page.getByTestId('reading-restore').isVisible(), true);
    assert.equal(await page.locator('#start-analysis').count(), 0);
    assert.match(await page.locator('#reading-detail').textContent(), /连接已停用/);
    await shot('28-reading-disabled.png', '连接停用时 · 保留原句并引导明确恢复', '#reading-window', 'settings');
    await page.getByTestId('reading-restore').click();
    await page.locator('[data-action="confirm-restore"]').click();
    assert.equal(await page.locator('#start-analysis').isVisible(), true);
    assert.equal(await page.evaluate(() => window.modelConfigDesign.state.readingStep), 'ready');
    checks.push('disabled_connection_blocks_reading_analysis_until_explicit_restore_without_autorun');

    await open('view=settings&tab=purposes');
    await page.locator('#tab-purposes').focus();
    await page.keyboard.press('ArrowRight');
    assert.equal(await page.locator('[role=tab][aria-selected=true]').getAttribute('data-tab'), 'connections');
    checks.push('content_tabs_keyboard_navigation');

    await page.setViewportSize({ width: 390, height: 844 });
    for (const [tab] of tabs) {
      await open(`view=settings&tab=${tab}&theme=light`);
      await noOverflow();
    }
    await open('view=settings&tab=purposes');
    await shot('20-narrow-settings.png', '窄视口 · 保留同样的配置功能');
    await open('view=reading&state=unconfigured');
    await noOverflow();
    await shot('21-narrow-reading.png', '窄视口 · 阅读与待配置对象', '#reading-window', 'responsive');
    checks.push('five_settings_tabs_and_reading_390_no_horizontal_overflow');
    assert.deepEqual(errors, [], 'Console or page errors');
    assert.deepEqual(requests, [], 'The prototype must not call HTTP services');
    const sources = {};
    for (const file of ['index.html', 'styles.css', 'prototype.js']) sources[file] = crypto.createHash('sha256').update(fs.readFileSync(path.join(path.dirname(input), file))).digest('hex');
    const result = { revision: 'model-configuration-v1', artifact_qa_passed: true, user_review: 'not_reviewed', runtime_tests: 'NOT_RUN', real_model_executed: false, product_regression_executed: false, mode: 'offline file:// design preview', browser: await browser.version(), source_sha256: sources, checks, captures, console_errors: errors, http_requests: requests };
    fs.writeFileSync(path.join(output, 'verification.json'), JSON.stringify(result, null, 2) + '\n');
    process.stdout.write(JSON.stringify({ artifact_qa_passed: true, checks, captures: captures.length, console_errors: errors.length, http_requests: requests.length }, null, 2) + '\n');
    await context.close();
  } finally { await browser.close(); }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
