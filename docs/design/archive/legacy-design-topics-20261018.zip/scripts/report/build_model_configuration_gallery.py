#!/usr/bin/env python3
"""Build the reviewed design gallery and a portable, source-preserving ZIP."""

import hashlib
import html
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[2]
DESIGN = ROOT / "docs/design/model-configuration-v1"
STYLE = """
:root{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;color:#242426;background:#f5f5f7}
*{box-sizing:border-box}body{max-width:1240px;margin:auto;padding:40px 28px 64px}h1{font-size:34px;letter-spacing:-.8px;margin:12px 0}h2{font-size:23px;letter-spacing:-.3px}p{line-height:1.75;color:#65656b}a{color:#0674e8;text-underline-offset:3px}.tag{font-size:12px;letter-spacing:.5px;color:#64646b}nav{display:flex;gap:18px;flex-wrap:wrap;line-height:1.7;margin:24px 0 30px}section{background:white;border:1px solid #dedee3;border-radius:18px;padding:24px;margin:24px 0}img{display:block;max-width:100%;height:auto;margin:20px auto 0;border-radius:10px}figure{margin:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.grid section{margin:0;padding:18px}small{color:#717177}.steps{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:25px 0}.steps span{padding:10px 15px;border-radius:9px;background:#e9edf3;color:#3b4856}.foot{font-size:13px}.jump{display:flex;gap:12px;flex-wrap:wrap}@media(max-width:700px){body{padding:24px 16px}.grid{grid-template-columns:1fr}h1{font-size:28px}section{padding:16px}}@media(prefers-color-scheme:dark){:root{background:#1d1d1f;color:#f5f5f7}section{background:#29292c;border-color:#45454c}p,small,.tag{color:#b8b8c2}.steps span{background:#333944;color:#e2e6ed}a{color:#69aafa}}
"""


def page(title, body):
    return f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>{STYLE}</style>{body}</html>\n'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    qa = json.loads((DESIGN / "previews/verification.json").read_text())
    if not qa["artifact_qa_passed"]:
        raise ValueError("Design browser verification must pass before packaging")
    for name, digest in qa["source_sha256"].items():
        if sha(DESIGN / name) != digest:
            raise ValueError(f"Design source changed after browser verification: {name}")
    captures = qa["captures"]
    nav = '<nav><a href="index.html">打开交互稿</a><a href="entry-flow.html">阅读进入配置</a><a href="../../product/model-configuration-prd.md">模型配置PRD</a><a href="previews/verification.json">设计检查记录</a></nav>'
    sections = []
    for shot in captures:
        src = "previews/" + shot["file"]
        sections.append(f'<section><h2>{html.escape(shot["title"])}</h2><p>{html.escape(shot.get("description", ""))}</p><a href="{src}"><img loading="lazy" src="{src}" alt="{html.escape(shot["title"])}"></a></section>')
    body = '<div class="tag">LUNA · 模型配置 v1 · 待视觉评审</div><h1>选择模型，也看清它何时生效。</h1><p>用途绑定、服务连接、模型、参数与模板、运行与数据。保存、测试、应用和启用各自有明确状态，阅读中的原句可以带着去配置，再回到原处。</p>' + nav
    body += '<div class="steps"><span>连接服务</span>→<span>选择模型</span>→<span>分配用途</span>→<span>应用并启用</span></div>'
    body += "".join(sections)
    body += f'<p class="foot">{len(captures)}张设计截图；离线浏览器检查通过，未调用真实模型。所有测试与解释均为设计数据，用户视觉评审 not_reviewed，产品回归 NOT_RUN。需求归属见 <a href="coverage.csv">16条配置需求覆盖清单</a>。</p>'
    (DESIGN / "gallery.html").write_text(page("Luna · 模型配置设计画廊", body))
    entry = [shot for shot in captures if shot.get("group") == "entry"]
    flow = '<div class="tag">从阅读进入 · 固定原句 · 配置后由用户开始</div><h1>看不懂的这一句，配置后仍是这一句。</h1><p>字幕右下“…” → 分析本句文法；也可点词打开词卡后进入。未配置时保留原句，配置完成后返回，用户主动开始。新台词不会替换等待中的分析对象。</p><nav><a href="index.html?view=reading&state=unconfigured">点击体验完整流程</a><a href="gallery.html">全部设计截图</a></nav>'
    for shot in entry:
        flow += f'<section><h2>{html.escape(shot["title"])}</h2><p>{html.escape(shot.get("description", ""))}</p><img src="previews/{shot["file"]}" alt="{html.escape(shot["title"])}"></section>'
    flow += '<p class="foot">此流程只验证离线HTML中的入口和对象保留；正式产品的模型请求、原生独立窗口及游戏前台行为仍待验收。</p>'
    (DESIGN / "entry-flow.html").write_text(page("Luna · 阅读到模型配置再返回", flow))
    inventory = []
    for path in sorted(DESIGN.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            inventory.append({"file": str(path.relative_to(DESIGN)), "bytes": path.stat().st_size, "sha256": sha(path)})
    manifest = {"revision": "model-configuration-v1", "user_review": "not_reviewed", "runtime_tests": "NOT_RUN", "real_model_executed": False, "requirements": 16, "prd_acceptance_cases_not_run": 22, "artifact_qa": "previews/verification.json", "files": inventory}
    (DESIGN / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    archive = ROOT / "reports/model-configuration-design-20261018.zip"
    prefix = "model-configuration-design-20261018/"
    landing = '<div class="tag">LUNA · 离线设计包</div><h1>模型配置与阅读返回流程</h1><p>打开交互稿或截图画廊即可评审。所有服务、测试和解释均为离线设计数据。</p><nav><a href="docs/design/model-configuration-v1/index.html">可交互设计稿</a><a href="docs/design/model-configuration-v1/gallery.html">截图画廊</a><a href="docs/design/model-configuration-v1/entry-flow.html">阅读进入配置</a></nav><p class="foot">附模型配置PRD、AI阅读PRD和22条待执行验收的源文档快照。PRD中指向完整项目其他资料的链接需回原项目查看；本包不包含应用程序或真实模型。</p>'
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as stream:
        stream.writestr(prefix + "index.html", page("Luna · 模型配置离线设计包", landing))
        for path in sorted(DESIGN.rglob("*")):
            if path.is_file():
                stream.write(path, prefix + str(path.relative_to(ROOT)))
        for name in ["model-configuration-prd.md", "ai-reading-prd.md", "model-configuration-acceptance.csv"]:
            path = ROOT / "docs/product" / name
            stream.write(path, prefix + str(path.relative_to(ROOT)))
    print(json.dumps({"archive": str(archive.relative_to(ROOT)), "bytes": archive.stat().st_size, "sha256": sha(archive), "captures": len(captures), "design_files": len(inventory) + 1}, ensure_ascii=False))


if __name__ == "__main__":
    main()
