# 客户端重建架构与实施边界

版本：规划 1.0 · 日期：2026-10-18 · 本轮范围：重建与回归规划，不实施产品代码、不运行新产品回归、不提交推送。

重建以当前可打包的 Rust/Tauri 客户端为基础，替换旧原生接入并补齐产品应用层。产品范围和交互继续来自原 PRD v1.2 的 56 项需求、22 屏设计。本文件是客户端后续开发入口；[旧开发架构](development-architecture.md)与既有 HTML 保留为迁移前记录。

本次补充：[日语分词与大模型方案](japanese-study-and-llm.md)及[开启分词后的待评审设计](../design/first-product-v1/index.html)。基础分词器和词典确定随客户端内置。M2 后增加 M2-L 学习切片，先评审可见效果，再实现本地词法、可配置翻译与按需文法；原产品优先级及完整验收保留。

## 1. 当前事实与交付差距

| 基础 | 已有事实 | 不能推导的结论 |
|---|---|---|
| 原产品资料 | 100 个文件、89 张设计图已固定来源与哈希；56 项需求有映射 | 导入不代表实现或视觉运行通过 |
| Luna Reader 0.1.1 | Tauri 2＋React、受管 Rust 宿主、目标/流选择、原文和短历史、macOS release `.app` | 尚无产品翻译服务、完整 HUD 和持久化；仍为原版 ABI |
| 精简 Core | 独立私有仓库，提交 `e9242ebac32a09e911f306b7c90714891c217302`；Hook、Host、Injector 及许可保留 | 当前 Reader 尚未接入 Core ABI 1 |
| Core 实机 | SR、MO、Never7、サクラノ詩 10th 原生探针取文和正常断开已验证 | 不等于 Rust 双架构回调、正式客户端显示、反复重连、长稳或翻译通过 |

Core 基线来自[脱敏验证摘要](../../../luna-hooks-core/verification/published-summary.json)。SR 是已安装的简体中文版；Never7 的五次新增对应三个文本页；MO 的早前图形/内存异常仍未归因。Ever17 不在本次游戏回归范围。

## 2. 复用和替换清单

| 模块 | 保留基础 | 必须修改或新增 |
|---|---|---|
| `hook-contracts` | 请求校验、完整流身份、64 位数值字符串、错误模型 | Core 专用 JSONL v2；移除嵌入字段，增加资源身份、序号与可靠状态 |
| `lunahook-host` | 单独进程、快速回调复制、帧处理、目标身份复核与关闭监督 | 七回调 C ABI、GetAbiVersion、32/64 构建、Core 文件名、注入参数与退出码 |
| `hook-client` | bottle/进程枚举、创建时间复验、会话 generation、私有管道和快照 | 按目标选 broker、Core manifest 校验、阶段化连接、总量限额与资源冲突处理 |
| Tauri 组合根 | 资源相对应用包定位、后台任务、命令桥与退出入口 | 接应用核心；多窗口/HUD 生命周期和权限按原设计实现 |
| React 窗口 | 目标选择、候选预览、历史显示等组件经验 | 移除 TextOutW 自动优先规则；按原稿重建 HUD、设置与产品状态 |
| 构建工具 | 哈希校验、许可证与正式应用包、离线启动方式 | 独立 Core 资源锁、干净 staging、双 broker、整套版本 manifest、旧资源残留检查 |
| 产品应用层 | 尚未形成完整实现 | 输入调度、阅读单元、翻译、配置、历史、凭据引用与产品 API |

先按职责在现有 crate 中重构；出现独立业务状态后再提取 `app-core`。不为目录整齐预先拆出大量空 crate，也不在本轮升级技术栈版本。Cargo.lock 与前端 lockfile 是后续实现的依赖基线。

## 3. 进程和调用边界

```mermaid
flowchart LR
  UI[Tauri React 客户端] -->|命令| APP[Rust 应用核心]
  APP -->|状态和阅读事件| UI
  APP --> MANAGER[hook-client 环境与会话管理]
  MANAGER <-->|私有 JSONL v2| BROKER[Windows Rust broker32 或 broker64]
  BROKER <-->|Core ABI 1 七回调| HOST[同位数 LunaHostCore]
  BROKER --> INJECT[同位数 LunaInjectCore]
  INJECT --> HOOK[游戏内 LunaHookCore]
  HOOK <-->|Core 私有管道| HOST
  APP --> TRANSLATE[翻译服务适配器]
  APP --> STORE[配置 历史 凭据引用]
  API[未来 Web API 与 CLI] --> APP
```

macOS UI 和应用核心是原生进程，不能直接加载 Windows PE DLL。broker 必须在目标所在 CrossOver bottle 中运行。Windows 原生环境可直接启动匹配 broker；原生 macOS 游戏需要另一个提取后端。

首版采用 target x86→broker32／Host32／Injector32／Hook32，target x64→对应 64 位集合。此部署选择收敛到 Core 已实测的同位数路径。UI 自身位数不决定游戏位数。一个 bottle 中同一目标只允许本应用一个接入 owner；不能与原版 Luna 或另一探针争用目标。

Core 的 V8 本机 HTTP 原文桥是引擎内部提取能力。产品 Web API 属于 Rust 应用层，尚未实现；两者不能混称。未来 Web API 应默认本机绑定、认证和限额，慢订阅者不得阻塞 Hook 或翻译。UI、CLI、API 复用用例，不对外暴露任意 DLL 路径或 FFI 入口。

## 4. 原生接入的硬约束

1. 核对固定 commit、ABI、架构、每文件 size/SHA-256，再加载 Host；只匹配 ABI 1 或通信 GUID 不足以证明同一版本集合。
2. Rust 使用 `extern "C"`，x86 不使用 stdcall。先调用 `Luna_GetAbiVersion`，再注册 connect、disconnect、create、destroy、output、info、hookInserted 七回调。Create 不再有 `embed_capable`。
3. ThreadParam 按值传递，当前布局 size 32、align 8，字段偏移 0/8/16/24。两种 Rust target 均须通过实际产物与 C++ 互操作检查，不能用 macOS 本机布局测试替代。未经布局核对不开放 SearchParam 等扩展入口。
4. 字符串在回调返回前有界复制；UTF-16、非法窄字节串、未知 info 值均有非 panic 处理。回调不等待 UI、HTTP、数据库，不同步重入 Host。panic 不跨 FFI。
5. 新注入器命令为 `<pid> <absolute Hook DLL path>`，没有 `dllinject` 子命令。退出 0 只表示确认加载；1 为操作失败，2 为参数/架构错误，3 为超时未确认。不能沿用旧成功码 1。
6. `Luna_ConnectProcess` 不会自动注入。建立监听、启动注入器、连接和文字回调之间可能交错；状态机处理真实事件，不强制假设严格时序。
7. Core 无 Stop/Join 或安全卸载确认。不热卸载仍存活的 Host DLL；重连用新 broker，断开与退出采用有限等待并标记未确认结果。绝不结束整个 bottle 或游戏来伪造清理成功。

## 5. 私有协议、状态与背压

当前实现是 JSONL v1。计划中的 v2 与 Core ABI 分别版本化，双方不兼容时在 attach 前拒绝。沿用 request_id 和完整流标识，并添加 host_instance、session_id、event_seq、Core commit/ABI、broker_arch、capabilities、integrity。64 位地址、创建时间、序号保持规范十进制字符串，避免 JavaScript 精度丢失。

v2 的字段和错误码由 M1 首个契约任务定稿，先新增 `hook-api-v2.md` 再实现两端；已实现的 v1 文档保留。不能提前把这些字段写成“当前已支持”。序号从 broker 接受自有事件后分配；它不能证明 Core 在回调之前没有丢数据，也不承诺重放不存在的原文。

连接显示区分：身份核验→资源就绪→监听/注入→native 已连接→候选流→已收到原文。注入器成功、ready、HookInserted 和 Connected 都不是 LiveText。游戏重开后必须重验 PID、完整路径、创建时间和架构；保存的可重用选流规则不能保存并盲用旧 PID/地址。

控制响应与文本事件分通道或保留容量，shutdown/detach 不能被正文洪流挤掉；stdout 只写协议，stderr 独立持续排空。回调队列满时不阻塞，保留丢失计数和粘性 `integrity_lost`。关键控制状态无法传达时使会话明确失败，不静默丢响应。

容量预算需覆盖 native 每流历史、回调队列、输出队列、控制请求、流数量、应用缓存和 UI 历史；目前并非整条链路都有总上限。M1 实测后记录字节/数量预算、峰值内存与恢复策略。会话有损时继续显示可以是用户选择，但不能验收为无丢失通过。

## 6. 原始事件、阅读单元与翻译

原始事件不可被 UI 规则覆盖。流身份由 PID、address、context、context2 加会话实例共同构成；不能按 Hook 名降维。候选列表排序只影响显示，不改变跨流合并顺序。新候选不抢占已选正文流，空列表不覆盖已保存配置。

SR 会按渲染行拆分；Never7 同页新增；MO 的首块可能包含相邻页；サクラノ詩 的同名候选质量可能不同。因此建立“原始事件→可追溯阅读单元→显示/翻译”三层，保留输入引用与规则版本。默认先忠实显示选流原文，合并和姓名提取为明确规则；不按固定游戏名、地址、事件数猜页界，不全局去重合法重复台词，也不简单删掉字符串共同前缀。

翻译任务归属 `(session_id, source_id, unit_id, text_revision, provider_revision)`。原文先显示，网络异步执行；迟到结果只更新所属历史，不能覆盖当前句。请求取消、暂停持续输入、关闭翻译和隐藏 HUD 是不同动作。真实服务超时、限流、凭据失效均可解释，原文显示持续可用。

配置分全局、配置档和游戏覆盖，保存与临时选择分开。配置有 schema/revision 和迁移/备份；保存失败保留草稿。历史持久化与候选预览缓存分离。凭据进入系统安全存储，配置只保留引用。具体数据库访问库和安全存储库在 M2 小型验证后记录 ADR；本轮不虚构已经落地的存储实现。

## 7. 按原稿重建产品交互

- SCR-04/05：目标/bottle、连接阶段、候选预览和正文/姓名选择；显式保存与临时应用。
- SCR-01：约 500×132pt、最小宽 360pt；原文 16pt、译文 22pt、状态 13pt，固定 32pt 操作行，默认暂停和更多。游戏前台时 HUD 不夺焦点。
- SCR-08：原文、译文、来源与完整性可追溯；旧译文不会错配当前句。
- SCR-12～21：十类单层设置，参考 1000×720pt、最小 900×600pt；翻译服务不再增加第二套侧栏。
- 关闭主窗口后后台仍可运行；菜单栏恢复隐藏/穿透。隐藏、暂停输入、停止翻译、断开和退出各自有语义。
- 手动输入与翻译服务测试不依赖已连接游戏；OCR、剪贴板、文件、学习工具、原生 macOS 等仍按原需求完成。

视觉比较使用原稿已确认的 aligned-v1／ocr-selection-v2；ocr-source-v1 和 compat-x86-v1 仍为待确认稿。Playwright 验证画面和交互，系统真机另验置顶、穿透、全屏、焦点、多屏、热键和辅助能力。网页截图不等于原生窗口通过。

## 8. 里程碑与发布门禁

| 阶段 | 可交付结果 | 必须通过的门禁 |
|---|---|---|
| M1 接入版 | 正式 `.app`＋ZIP，Core 专用资源锁、双 broker、真实原文/选流/历史和生命周期 | 两架构 Rust 真实回调；最终包四游戏≥5变化状态；正常断开游戏继续；资源失败与压力恢复 |
| M2 产品闭环 | 原设计 HUD、真实翻译、配置/凭据、持久历史，脱离游戏也能手动翻译 | 真实请求→对应译文→历史；迟到/失败/重开不串句；设计对照和原生窗口行为 |
| M2-L 学习切片 | 内置 MeCab/UniDic、ruby/POS/词卡、独立模型用途、按需 AI 文法 | 设计评审；离线首启；词法位置和读音；真实服务/文法质量；最终包四游戏复验 |
| M3 完整范围 | 原 PRD 的其余 P0，再按 P1/P2 完成扩展；能力按平台显示 | 56 REQ 逐项独立验收，Windows/native macOS 等证据不互借 |

先完成一个垂直闭环再扩大并行：契约/资源→broker→受管客户端→最终包→四游戏回归。应用模型与原设计组件可以在契约定稿后并行；翻译、数据库和 Web API 不与 DLL FFI 混在一个大改动中。详细依赖见[任务 CSV](../development/client-rebuild-tasks.csv)。本次方案对原 D1/GE 阻塞全部 D2～D6 开发的顺序提出替代，详见 ADR-003；完整 D1/GE 与 P0 的功能/平台要求及未达成状态继续保留。

构建必须从干净 staging 组包，包中声明应用/协议/broker/Core commit/ABI/工具链/资源哈希，并包含 GPL 与第三方许可。旧版对照包独立保留，升级整套 runtime，不覆盖已加载 DLL；不要求生产用户装 Python、源码或开发服务器。签名/公证、Windows 安装包与自动更新各自列发布门禁，不能把本机 ZIP 当作已完成。

## 9. 回归证据与状态

回归从最终 release 包开始，而非从命令行探针结束。先做接入前检查，再逐款完整走“启动→选择目标→连接→选流→推进→HUD/历史→断开→游戏继续”，前一款失败先修复和重跑，再记录下一款。原49项客户端 TC 全文未导入，本次建立新的 CR 编号，不冒充恢复旧测试清单。

用例与产品需求映射见[回归计划](../development/client-regression.md)和[可执行矩阵](../development/client-regression.csv)。本轮新产品用例均为 `not_run`。将来每次结果绑定最终包 hash、Core 身份、平台/bottle、游戏版本与进程身份；明确区分 passed、failed、blocked、not_run。正常正文与翻译闭环不能在关键结果未知或有损时通过；故障用例可因正确检测、隔离并报告 unknown/loss 而通过，但该故障采集不能被当作无损正文证据。

原始字幕、游戏截图、进程 sample、密钥与个人路径默认只保留本地诊断目录；分享报告只附脱敏统计与限制。MO 的既往异常单列问题，不因能读字就宣布已修复。完整剧情、反复重连和长稳必须有独立样本，四款短序列不能代替。

## 10. 依据与后续入口

- [ADR-003](ADR-003-client-rebuild-on-core.md)：本次架构选择与替代范围。
- [原 PRD](../product/original/docs/01-prd.md)、[设计规范](../product/original/docs/02-design-spec.md)、[原画廊](../product/original/design/index.html)：原始产品依据，保持字节不变。
- [开发计划](../development/plan.md)、[任务清单](../development/client-rebuild-tasks.csv)、[56项需求映射](../development/requirements.csv)：里程碑与执行依赖。
- [Core ABI 文档](../../../luna-hooks-core/docs/abi.md)及其源码：七回调与注入器的权威边界；客户端未来须绑定固定提交。

本轮交付的是可实施、可验收的方案。现有生产代码、原始产品快照、运行中游戏与 Core 仓库不因规划发生变更。
